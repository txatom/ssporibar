var isBijoy = true;


function makeBanglaInput(tbid)
{
	myTextAreaID = tbid;

		makeBijoyKeybdEditor("txtTitle");
		makeBijoyKeybdEditor("txtContent");
		makeBijoyKeybdEditor("txtTag");

	}

